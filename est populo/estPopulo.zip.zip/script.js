const scroll = new LocomotiveScroll({
    el: document.querySelector('.main'),
    smooth: true
});